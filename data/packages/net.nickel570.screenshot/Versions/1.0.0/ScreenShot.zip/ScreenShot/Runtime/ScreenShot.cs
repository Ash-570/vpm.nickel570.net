using System;
using System.Collections;
using System.IO;
using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace ScreenshotUtility
{
    // タイムスタンプ形式
    public enum TIME_STAMP
    {
        MMDDHHMMSS,
        YYYYMMDDHHMMSS,
    }

    // 背景タイプ
    public enum BACK_GROUND_COLOR
    {
        Alpha,       // 透過PNG
        CustomColor, // カスタムカラー
        Skybox,      // スカイボックス
        BackgroundImage, // 背景画像
    }

    // 出力解像度
    public enum SCREEN_SIZE_PIXEL
    {
        // 1:1
        p256x256,
        p512x512,
        p1024x1024,
        p2048x2048,
        p4096x4096,

        // 16:9
        p1280x720,   // HD
        p1920x1080,  // FullHD
        p2560x1440,  // 2k
        p3840x2160,  // 4k

        CustomSize   // 手動指定(下限32 / 上限4096)
    }

    public class ScreenShot : MonoBehaviour
    {
#if UNITY_EDITOR
        [Header("撮影に使うカメラ")]
        [Tooltip("撮影に使用するカメラを割り当ててください")]
        [SerializeField] private Camera _useCamera;

        [Tooltip("撮影時にカメラの位置・画角を自動的にシーンビューに合わせる")]
        [SerializeField] private bool _syncWithSceneView = true;

        [Header("画像サイズ設定")]
        [Tooltip("CustomSize を選択すると、_customSize の解像度が適用されます")]
        [SerializeField] private SCREEN_SIZE_PIXEL _screenSizePixel = SCREEN_SIZE_PIXEL.p1024x1024;

        [Tooltip("ScreenSizePixel が CustomSize の場合の解像度（下限32 / 上限4096）")]
        [SerializeField] private Vector2Int _customSize = new Vector2Int(1024, 1024);

        [Header("背景色設定")]
        [Tooltip("Alpha:透過 / CustomColor:指定色 / Skybox:スカイボックス")]
        [SerializeField] private BACK_GROUND_COLOR _backgroundColorType = BACK_GROUND_COLOR.Alpha;

        [Tooltip("BackgroundColorType が CustomColor の場合の背景色")]
        [SerializeField] private Color _customColor = Color.green;

        [Tooltip("BackgroundColorType が BackgroundImage の場合の背景画像")]
        [SerializeField] private Texture2D _backgroundImage;

        [Header("ファイル名設定")]
        [Tooltip("タイムスタンプ書式")]
        [SerializeField] private TIME_STAMP _timeStampStyle = TIME_STAMP.MMDDHHMMSS;

        [Tooltip("ファイル名の先頭に付く文字列")]
        [SerializeField] private string _screenShotsTitle = "img";

        [Header("保存先フォルダ名")]
        [Tooltip("Assets 直下に作成されるフォルダ名")]
        [SerializeField] private string _screenShotFolderName = "ScreenShots";

        [Header("実行中の撮影キー")]
        [Tooltip("Play中にスクリーンショットを撮るためのキー")]
        public KeyCode _screenShotsKeybinding = KeyCode.F1;

        [Header("ログ出力")]
        [Tooltip("保存したファイル名とパスを Console に出力します")]
        [SerializeField] private bool _consoleLogIsActive = true;

        private void Update()
        {
            if (Input.GetKeyDown(_screenShotsKeybinding))
            {
                CaptureScreenshot();
            }
        }

        private bool HasNullOrInvalidSetting()
        {
            bool hasError = false;

            if (_useCamera == null)
            {
                Debug.LogWarning("[ScreenShot] 撮影に使用するカメラを _useCamera に割り当ててください。");
                hasError = true;
            }

            if (string.IsNullOrWhiteSpace(_screenShotsTitle))
            {
                Debug.LogWarning("[ScreenShot] _screenShotsTitle にファイル名の先頭文字列を設定してください。");
                hasError = true;
            }

            if (string.IsNullOrWhiteSpace(_screenShotFolderName))
            {
                Debug.LogWarning("[ScreenShot] _screenShotFolderName に保存先フォルダ名を設定してください。");
                hasError = true;
            }

            if (_backgroundColorType == BACK_GROUND_COLOR.BackgroundImage && _backgroundImage == null)
            {
                Debug.LogWarning("[ScreenShot] 背景タイプが BackgroundImage ですが、背景画像が設定されていません。");
                hasError = true;
            }

            return hasError;
        }

        // 変更点1: CaptureScreenshot で分岐
        [ContextMenu("スクリーンショットを撮影する")]
        public void CaptureScreenshot()
        {
            if (HasNullOrInvalidSetting()) return;

            if (_syncWithSceneView)
            {
                AlignCameraToSceneView();
            }

            string path = Path.Combine(Application.dataPath, _screenShotFolderName) + "/";

            if (Application.isPlaying)
            {
                StartCoroutine(CaptureRoutine(path, _screenShotsTitle));
            }
            else
            {
                CaptureImmediate(path, _screenShotsTitle); // ★停止中はこちら
            }
        }


        // 撮影コルーチン
        private IEnumerator CaptureRoutine(string path, string title)
        {
            // 描画完了待ち
            yield return new WaitForEndOfFrame();

            EnsureDirectory(path);

            string fileName = $"{title}{GetTimeStamp(_timeStampStyle)}.png";
            string fullPath = Path.Combine(path, fileName);

            // 元の背景設定をキャッシュ
            var camera = _useCamera;
            Color originalBgColor = camera.backgroundColor;
            CameraClearFlags originalClearFlags = camera.clearFlags;

            // 背景設定
            switch (_backgroundColorType)
            {
                case BACK_GROUND_COLOR.Alpha:
                    camera.backgroundColor = new Color(0f, 0f, 0f, 0f);
                    camera.clearFlags = CameraClearFlags.SolidColor;
                    break;

                case BACK_GROUND_COLOR.CustomColor:
                    camera.backgroundColor = _customColor;
                    camera.clearFlags = CameraClearFlags.SolidColor;
                    break;

                case BACK_GROUND_COLOR.Skybox:
                    camera.clearFlags = CameraClearFlags.Skybox;
                    break;

                case BACK_GROUND_COLOR.BackgroundImage:
                    camera.backgroundColor = new Color(0f, 0f, 0f, 0f);
                    camera.clearFlags = CameraClearFlags.Depth;
                    break;
            }

            // 解像度決定
            Vector2Int size = GetScreenSize(_screenSizePixel);

            // レンダリング
            Texture2D screenShot = new Texture2D(size.x, size.y, TextureFormat.ARGB32, false);
            RenderTexture rt = new RenderTexture(size.x, size.y, 24, RenderTextureFormat.ARGB32);

            var prevTarget = camera.targetTexture;
            var prevActive = RenderTexture.active;

            try
            {
                if (_backgroundColorType == BACK_GROUND_COLOR.BackgroundImage && _backgroundImage != null)
                {
                    Graphics.Blit(_backgroundImage, rt);
                }

                camera.targetTexture = rt;
                camera.Render();

                RenderTexture.active = rt;
                screenShot.ReadPixels(new Rect(0, 0, size.x, size.y), 0, 0);
                screenShot.Apply();

                byte[] bytes = screenShot.EncodeToPNG();
                File.WriteAllBytes(fullPath, bytes);
            }
            finally
            {
                // 後始末
                camera.targetTexture = prevTarget;
                RenderTexture.active = prevActive;

                if (Application.isPlaying)
                {
                    Destroy(rt);
                    Destroy(screenShot);
                }
                else
                {
                    DestroyImmediate(rt);
                    DestroyImmediate(screenShot);
                }

                // 背景を元に戻す
                camera.backgroundColor = originalBgColor;
                camera.clearFlags = originalClearFlags;
            }

            if (_consoleLogIsActive)
            {
                Debug.Log($"[ScreenShot] Saved: {fileName}");
                Debug.Log($"[ScreenShot] Path : {fullPath}");
            }

            // AssetDB 更新（Editorのみ）
#if UNITY_EDITOR
            AssetDatabase.Refresh();
#endif
        }

        // 保存先フォルダ確認
        private void EnsureDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
                Debug.Log($"[ScreenShot] CreateFolder: {path}");
            }
        }

        // 解像度取得
        private Vector2Int GetScreenSize(SCREEN_SIZE_PIXEL type)
        {
            if (_backgroundColorType == BACK_GROUND_COLOR.BackgroundImage && _backgroundImage != null)
            {
                return new Vector2Int(_backgroundImage.width, _backgroundImage.height);
            }

            Vector2Int size;

            switch (type)
            {
                // 1:1
                case SCREEN_SIZE_PIXEL.p256x256:
                    size = new Vector2Int(256, 256);
                    break;
                case SCREEN_SIZE_PIXEL.p512x512:
                    size = new Vector2Int(512, 512);
                    break;
                case SCREEN_SIZE_PIXEL.p1024x1024:
                    size = new Vector2Int(1024, 1024);
                    break;
                case SCREEN_SIZE_PIXEL.p2048x2048:
                    size = new Vector2Int(2048, 2048);
                    break;
                case SCREEN_SIZE_PIXEL.p4096x4096:
                    size = new Vector2Int(4096, 4096);
                    break;

                // 16:9
                case SCREEN_SIZE_PIXEL.p1280x720:
                    size = new Vector2Int(1280, 720);
                    break;
                case SCREEN_SIZE_PIXEL.p1920x1080:
                    size = new Vector2Int(1920, 1080);
                    break;
                case SCREEN_SIZE_PIXEL.p2560x1440:
                    size = new Vector2Int(2560, 1440);
                    break;
                case SCREEN_SIZE_PIXEL.p3840x2160:
                    size = new Vector2Int(3840, 2160);
                    break;

                // Custom
                case SCREEN_SIZE_PIXEL.CustomSize:
                    int x = Mathf.Clamp(_customSize.x, 32, 4096);
                    int y = Mathf.Clamp(_customSize.y, 32, 4096);

                    if (x != _customSize.x)
                        Debug.LogWarning("[ScreenShot] PixelSize X を範囲外のため補正しました (32〜4096)");
                    if (y != _customSize.y)
                        Debug.LogWarning("[ScreenShot] PixelSize Y を範囲外のため補正しました (32〜4096)");

                    _customSize = new Vector2Int(x, y);
                    size = _customSize;
                    break;

                default:
                    size = new Vector2Int(1024, 1024);
                    Debug.LogWarning("[ScreenShot] 未定義の SCREEN_SIZE_PIXEL が指定されました。1024x1024 で出力します。");
                    break;
            }

            return size;
        }

        // タイムスタンプ生成
        private string GetTimeStamp(TIME_STAMP type)
        {
            switch (type)
            {
                case TIME_STAMP.MMDDHHMMSS:
                    return DateTime.Now.ToString("MMddHHmmss");
                case TIME_STAMP.YYYYMMDDHHMMSS:
                    return DateTime.Now.ToString("yyyyMMddHHmmss");
                default:
                    return DateTime.Now.ToString("yyyyMMddHHmmss");
            }
        }

        // 追加: 停止中用の即時キャプチャ
        private void CaptureImmediate(string path, string title)
        {
            EnsureDirectory(path);

            string fileName = $"{title}{GetTimeStamp(_timeStampStyle)}.png";
            string fullPath = Path.Combine(path, fileName);

            var camera = _useCamera;
            Color originalBgColor = camera.backgroundColor;
            CameraClearFlags originalClearFlags = camera.clearFlags;

            // 背景設定
            switch (_backgroundColorType)
            {
                case BACK_GROUND_COLOR.Alpha:
                    camera.backgroundColor = new Color(0f, 0f, 0f, 0f);
                    camera.clearFlags = CameraClearFlags.SolidColor;
                    break;
                case BACK_GROUND_COLOR.CustomColor:
                    camera.backgroundColor = _customColor;
                    camera.clearFlags = CameraClearFlags.SolidColor;
                    break;
                case BACK_GROUND_COLOR.Skybox:
                    camera.clearFlags = CameraClearFlags.Skybox;
                    break;
                case BACK_GROUND_COLOR.BackgroundImage:
                    camera.backgroundColor = new Color(0f, 0f, 0f, 0f);
                    camera.clearFlags = CameraClearFlags.Depth;
                    break;
            }

            // 解像度
            Vector2Int size = GetScreenSize(_screenSizePixel);

            // レンダリング（同期）
            var rt = new RenderTexture(size.x, size.y, 24, RenderTextureFormat.ARGB32);
            var tex = new Texture2D(size.x, size.y, TextureFormat.ARGB32, false);

            var prevTarget = camera.targetTexture;
            var prevActive = RenderTexture.active;

            try
            {
                if (_backgroundColorType == BACK_GROUND_COLOR.BackgroundImage && _backgroundImage != null)
                {
                    Graphics.Blit(_backgroundImage, rt);
                }

                camera.targetTexture = rt;
                camera.Render();

                RenderTexture.active = rt;
                tex.ReadPixels(new Rect(0, 0, size.x, size.y), 0, 0);
                tex.Apply();

                File.WriteAllBytes(fullPath, tex.EncodeToPNG());

        #if UNITY_EDITOR
                if (_consoleLogIsActive)
                {
                    Debug.Log($"[ScreenShot] Saved: {fileName}");
                    Debug.Log($"[ScreenShot] Path : {fullPath}");
                }
                AssetDatabase.Refresh();
        #endif
            }
            finally
            {
                camera.targetTexture = prevTarget;
                RenderTexture.active = prevActive;

        #if UNITY_EDITOR
                UnityEngine.Object.DestroyImmediate(rt);
                UnityEngine.Object.DestroyImmediate(tex);
        #else
                UnityEngine.Object.Destroy(rt);
                UnityEngine.Object.Destroy(tex);
        #endif

                camera.backgroundColor = originalBgColor;
                camera.clearFlags = originalClearFlags;
            }
        }

        private void AlignCameraToSceneView()
        {
            if (_useCamera == null) return;

            var sceneView = UnityEditor.SceneView.lastActiveSceneView;
            if (sceneView == null && UnityEditor.SceneView.sceneViews.Count > 0)
            {
                sceneView = (UnityEditor.SceneView)UnityEditor.SceneView.sceneViews[0];
            }

            if (sceneView == null || sceneView.camera == null) return;

            UnityEditor.Undo.RecordObject(_useCamera.transform, "Align Camera to Scene View");
            UnityEditor.Undo.RecordObject(_useCamera, "Align Camera Settings to Scene View");

            _useCamera.transform.position = sceneView.camera.transform.position;
            _useCamera.transform.rotation = sceneView.camera.transform.rotation;
            
            _useCamera.orthographic = sceneView.camera.orthographic;
            if (_useCamera.orthographic)
            {
                _useCamera.orthographicSize = sceneView.camera.orthographicSize;
            }
            else
            {
                _useCamera.fieldOfView = sceneView.camera.fieldOfView;
            }
        }

#endif
    }
}

