using UnityEditor;
using UnityEngine;
using ScreenshotUtility;

namespace ScreenshotUtility.Editor
{
    public class ScreenShotWindow : EditorWindow
    {
        private ScreenShot _targetScreenShot;
        private SerializedObject _serializedObject;
        private Vector2 _scrollPos;

        [MenuItem("Tools/Nickel570/Nike's ScreenShot")]
        public static void ShowWindow()
        {
            var window = GetWindow<ScreenShotWindow>("ScreenShot");
            window.minSize = new Vector2(320, 500);
        }

        private void OnEnable()
        {
            FindTarget();
        }

        private void FindTarget()
        {
            _targetScreenShot = FindObjectOfType<ScreenShot>();
            if (_targetScreenShot != null)
            {
                _serializedObject = new SerializedObject(_targetScreenShot);
            }
        }

        private void OnGUI()
        {
            if (_targetScreenShot == null)
            {
                EditorGUILayout.HelpBox("シーン内に ScreenShot コンポーネントが見つかりません。\nヒエラルキーに ScreenShot オブジェクト（またはプレハブ）を配置してください。", MessageType.Warning);
                
                if (GUILayout.Button("シーンから再検索", GUILayout.Height(30)))
                {
                    FindTarget();
                }
                return;
            }

            if (_serializedObject == null || _serializedObject.targetObject == null)
            {
                FindTarget();
                if (_serializedObject == null) return;
            }

            _serializedObject.Update();

            _scrollPos = EditorGUILayout.BeginScrollView(_scrollPos);

            // 1. カメラ設定 (Camera Settings)
            DrawHeader("Camera Settings");
            EditorGUILayout.BeginVertical(GUI.skin.box);
            EditorGUILayout.PropertyField(_serializedObject.FindProperty("_useCamera"));
            
            GUILayout.Space(5);
            EditorGUILayout.PropertyField(_serializedObject.FindProperty("_syncWithSceneView"), new GUIContent("シーンビューの視点"));
            EditorGUILayout.EndVertical();

            // 2. 解像度設定 (Resolution Settings)
            DrawHeader("Resolution Settings");
            EditorGUILayout.BeginVertical(GUI.skin.box);
            SerializedProperty sizeProp = _serializedObject.FindProperty("_screenSizePixel");
            EditorGUILayout.PropertyField(sizeProp);
            
            // CustomSizeの時だけカスタムサイズの数値を表示
            if (sizeProp.enumValueIndex == (int)SCREEN_SIZE_PIXEL.CustomSize)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(_serializedObject.FindProperty("_customSize"));
                EditorGUI.indentLevel--;
            }
            EditorGUILayout.EndVertical();

            // 3. 背景設定 (Background Settings)
            DrawHeader("Background Settings");
            EditorGUILayout.BeginVertical(GUI.skin.box);
            SerializedProperty bgProp = _serializedObject.FindProperty("_backgroundColorType");
            EditorGUILayout.PropertyField(bgProp);
            
            // 選択された背景タイプに応じて表示する項目を切り替える
            if (bgProp.enumValueIndex == (int)BACK_GROUND_COLOR.CustomColor)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(_serializedObject.FindProperty("_customColor"));
                EditorGUI.indentLevel--;
            }
            else if (bgProp.enumValueIndex == (int)BACK_GROUND_COLOR.BackgroundImage)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.PropertyField(_serializedObject.FindProperty("_backgroundImage"));
                EditorGUILayout.HelpBox("背景画像が設定されている場合、上の「Resolution Settings」の値は無視され、画像の解像度が優先して適用されます。", MessageType.Info);
                EditorGUI.indentLevel--;
            }
            EditorGUILayout.EndVertical();

            // 4. 出力設定 (Output Settings)
            DrawHeader("Output Settings");
            EditorGUILayout.BeginVertical(GUI.skin.box);
            EditorGUILayout.PropertyField(_serializedObject.FindProperty("_screenShotFolderName"));
            EditorGUILayout.PropertyField(_serializedObject.FindProperty("_screenShotsTitle"));
            EditorGUILayout.PropertyField(_serializedObject.FindProperty("_timeStampStyle"));
            EditorGUILayout.PropertyField(_serializedObject.FindProperty("_screenShotsKeybinding"));
            EditorGUILayout.PropertyField(_serializedObject.FindProperty("_consoleLogIsActive"));
            EditorGUILayout.EndVertical();

            _serializedObject.ApplyModifiedProperties();

            EditorGUILayout.EndScrollView();

            GUILayout.Space(10);
            
            // 撮影ボタン
            GUI.backgroundColor = new Color(0.6f, 1f, 0.6f);
            if (GUILayout.Button("スクリーンショットを撮影する", GUILayout.Height(40)))
            {
                _targetScreenShot.CaptureScreenshot();
            }
            GUI.backgroundColor = Color.white;
            GUILayout.Space(5);
        }

        private void DrawHeader(string title)
        {
            GUILayout.Space(8);
            EditorGUILayout.LabelField(title, EditorStyles.boldLabel);
        }

        private void OnHierarchyChange()
        {
            // ヒエラルキーが変更されたらターゲットを取り直す
            FindTarget();
            Repaint();
        }
    }
}
